ASB SimpleProxy - Portable Version

Version: 1.0.0
Date: 2026-01-27

Features:
- HTTP/HTTPS proxy support
- Authentication handling
- Multilingual interface (English/Russian)
- Automatic proxy configuration

How to use:
1. Run ASB SimpleProxy.exe
2. Enter proxy IP address and port
3. Enter username and password (if required)
4. Click "Connect"

Requirements:
- Windows 10/11
- Administrator privileges
